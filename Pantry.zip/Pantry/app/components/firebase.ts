"use server";
import * as admin from "firebase-admin";
import * as serviceAccount from "../../service.json";
import {getFirestore} from "firebase-admin/firestore";
import { ExpandRounded } from "@mui/icons-material";
try {
  admin.initializeApp({
  credential: admin.credential.cert(serviceAccount as admin.ServiceAccount), 
  databaseURL: process.env.DATABASE_URL
})
}
catch(e) {
  console.log(e)
}
const firestore = getFirestore();
export async function getData(user: string): Promise<Object> {
 const document = firestore.collection("users").doc(user)
  let doc = (await document.get()).data();
  if(!doc) {
    await document.set({});
    doc = {};
  }
  return doc;

}
export async function deleteData(user: string, item: string): Promise<Object> {
  const document = firestore.collection("users").doc(user);
  await document.update({
    [item]: admin.firestore.FieldValue.delete()
  });
  return await getData(user);
}

export async function updateData(user: string, item: string, value: string) {
  const document = firestore.collection("users").doc(user);
  await document.update({
    [item]: value
  });
}
export async function addData(user: string,item:string,value:string): Promise<Object> {
  const document = firestore.collection("users").doc(user);
  await document.update({
    [item]: value
  });
  return await getData(user);
}