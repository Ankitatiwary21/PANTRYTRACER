"use client";
import { useSession, signIn, signOut } from "next-auth/react";
import { useEffect, useState } from "react";
import {getData,deleteData,updateData,addData} from "./components/firebase";

import Divider from '@mui/material/Divider';
import Chip from "@mui/material/Chip";
import Tooltip from "@mui/material/Tooltip"
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import DeleteIcon from "@mui/icons-material/Delete"
import Avatar from "@mui/material/Avatar";
import CircularProgress from '@mui/material/CircularProgress';
import AppBar from "@mui/material/AppBar";
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

export default function Home() {
  let { data: user, status } = useSession();
  const [data, setData] = useState(null);
  useEffect(() => {
    if (status === "authenticated") {
      getData(user.user.email).then((doc) => {
        setData(doc);
      });
    }
  }, [status, user]);
  async function deleteItem(item:string) {
    setData(await deleteData(user.user.email, item));
  }
  async function addItem(item:string,quantity:string) {
    setData(await addData(user.user.email,item,quantity));
    (document.getElementById("new-item") as HTMLInputElement).value = '';
    (document.getElementById("new-quantity") as HTMLInputElement).value = '1';
  } 

  switch (status) {
    case "loading": {
      return (
        <CircularProgress color="secondary" style={{ position: "fixed", top: "calc(50% - 100px)", left: "calc(50% - 100px)" }} size="200px" />
      )
    }
    case "unauthenticated": {
      return (
        <div style={{ height: "100vh", display: "grid", placeItems: "center" }}>
          <Button size="large" color="secondary" variant="contained" onClick={() => signIn("google")}>Sign In with Google</Button>
        </div>
      )
    }
    case "authenticated": {
      return (
        <div style={{ height: "auto", minHeight: "100vh" }}>
          <AppBar style={{ position: "relative", flexDirection: "row-reverse", alignItems: "center" }}>
           <Tooltip title={user.user.name + " (" + user.user.email + ")"}><IconButton>
              <Avatar src={user.user.image} alt="user avatar" />
            </IconButton></Tooltip>
            <Button color="error" variant="contained" onClick={() => signOut()}>Sign Out</Button>
            <h2 style={{position:"absolute", left:0}}>Pantry Tracer</h2>
          </AppBar>
          {data ? (
            <div style={{ position: "relative" }}>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell style={{background:"black"}}><h2><b>Item</b></h2></TableCell>
                      <TableCell style={{background:"black"}} align="right"><h2><b>Quantity</b></h2></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {Object.keys(data).map((key) => {
                      return (<TableRow id={key}
                        key={key}
                        sx={{ '&:last-child td, &:last-child th': { border: 0 },  '&:nth-of-type(odd)': {
                          backgroundColor: "#d4d4d4",
                        }, }}
                      >
                        <TableCell component="th" scope="row">
                          <h3>{key}</h3>
                        </TableCell>
                        <TableCell align="right">
                        <TextField required onInput={ () => updateData(user.user.email,key,(document.getElementById(key+"-quantity") as HTMLInputElement)?.value as string)} defaultValue={data[key]} id={key +"-quantity"} label={key} type="number" InputLabelProps={{ shrink: true, }} variant="outlined"/>
                        <IconButton onClick={() => {deleteItem(key)}} aria-label="delete"><DeleteIcon /></IconButton>
                        </TableCell>
                      </TableRow>)
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
              <br></br>
              <Divider  variant="fullWidth"><Chip  label="Add Item" color='primary' size="medium" /></Divider>
              <br></br>
              <TableContainer component={Paper}>
              <Table style={{background:"#d4d4d4"}}>
                <TableBody>
              <TableRow>
                      <TableCell>
                        <TextField required id="new-item" label="Item" type="text" InputLabelProps={{ shrink: true, }} variant="standard"/>
                      </TableCell>
                      <TableCell align="right">
                        <TextField required id="new-quantity" defaultValue={1} label="Quantity" type="number" InputLabelProps={{ shrink: true, }} variant="standard"/>
                        <Button onClick={() => {addItem((document.getElementById("new-item")as HTMLInputElement).value,(document.getElementById("new-quantity") as HTMLInputElement).value)}} variant="contained">Add</Button>
                      </TableCell>
                    </TableRow>
                    </TableBody>
              </Table>
              </TableContainer>
            </div>
          ) : (
            <CircularProgress color="secondary" style={{ position: "fixed", top: "calc(50% - 100px)", left: "calc(50% - 100px)" }} size="200px" />
          )
          }
        </div>
      )
    }
  }
}