import { Inter } from "next/font/google";
import type { Metadata } from 'next'
import { AppRouterCacheProvider } from '@mui/material-nextjs/v13-appRouter';
import SessionWrapper from './components/SessionWrapper'
const inter = Inter({ subsets: ["latin"] });
import "./globals.css"
export const metadata: Metadata = {
  title: "Pantry Tracer",
  description: "A simple pantry tracker app made using Next.js, Firebase, and Material UI"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <SessionWrapper>
    <html lang="en">
      <AppRouterCacheProvider>
        <body className={inter.className}>{children}</body>
      </AppRouterCacheProvider>
    </html>
    </SessionWrapper>
  );
}
